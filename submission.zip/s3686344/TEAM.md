# Team Information

**Course:** RMIT COSC1125/1127 Artificial Intelligence

**Semester:** Semester 2, 2020

**Instructor:** Prof. Sebastian Sardina

**Student details:**

* Student 1's 3686344 - Zeyu Liu - s3686344@student.rmit.edu.au - ljq41911900

Student number should just be the **numbers**.